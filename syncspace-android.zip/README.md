# 栖云 Syncspace

栖云是一个自托管的个人文件同步空间，支持 Windows、Linux、Android 手机和平板，以及浏览器网页访问。文件按账号隔离，服务器端不设置单文件或账号配额；实际容量取决于服务器磁盘和设备能力。

## Linux 部署

需要 Python 3.10 或更高版本，不需要第三方 Python 包：

```bash
python3 server.py
```

启动后访问 `http://服务器地址:8765`。首次访问可注册账号，其他设备使用同一个账号登录。数据默认保存在 `data/`，可通过 `SYNC_DATA` 和 `PORT` 修改。生产环境应放在 HTTPS 反向代理后，并设置 `COOKIE_SECURE=true`。

## 网页功能

- 上传文件、上传文件夹、拖拽上传和拖拽合并。
- 下载单个文件，或导出全部文件为 ZIP。
- 删除文件和文件夹，文件夹删除会递归删除其中内容。
- 同名文件会保留为冲突副本。
- Windows/Linux Chromium 浏览器可以选择一个本地文件夹。浏览器会记住这个选择，只扫描该文件夹及其子目录，不会扫描设备全部文件夹。
- 选择的本地文件夹在网页打开期间每 60 秒自动同步，也可手动点击“立即同步”。本地增删改和云端增删改会互相同步。

## Android 扫描同步

Android 客户端使用系统 Storage Access Framework。首次使用点击“同步文件夹”，选择一个目录并授予读写权限；应用只会扫描该目录及子目录，并记住目录授权。客户端每 60 秒自动扫描同步，应用回到前台时也会触发同步，并提供“立即同步”按钮。本地新增和修改文件上传到云端，云端新增文件下载到已选择目录，已记住的本地文件删除会删除云端文件，云端删除会删除本地未修改副本。选择目录后会启动 Android `dataSync` 前台服务，因此 WebView 页面关闭后仍可继续运行；Android 系统仍可能因省电策略暂停服务。WebView 中继续提供账号登录、文件浏览、手动上传、删除和导出下载。

Android 系统可能限制应用完全退出后的后台任务；需要持续后台同步时，应在系统设置中允许栖云自启动和后台运行。同步目录必须由用户明确选择，应用不会请求或扫描整个设备存储空间。

## 构建 Android APK

使用 Android Studio 打开 `android/` 目录，安装 JDK 17、Android SDK Platform 35 和 Gradle 工具，然后构建 Debug APK：

```bash
gradlew.bat :app:assembleDebug
```

生成文件通常为 `android/app/build/outputs/apk/debug/app-debug.apk`。当前开发环境已经配置 JDK 17 和 Android SDK Platform 35，SDK 路径记录在 `android/local.properties`；Gradle 发行包仍需完成下载后即可构建 APK。`android/` 是完整可构建工程。

## 测试和打包

```bash
python -m unittest discover -s tests -v
python -m py_compile server.py tests/test_api.py
```

执行 `package.ps1` 会生成 Linux 部署 ZIP 和 Android ZIP。Android ZIP 只有在 APK 已构建时才会生成，脚本不会把源码冒充安装包。
