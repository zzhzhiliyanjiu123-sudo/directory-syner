import http.cookiejar
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from io import BytesIO
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            cls.port = sock.getsockname()[1]
        env = os.environ.copy()
        env["SYNC_DATA"] = str(Path(cls.temp.name) / "data")
        env["PORT"] = str(cls.port)
        env["HOST"] = "127.0.0.1"
        cls.proc = subprocess.Popen([sys.executable, str(ROOT / "server.py")], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.base = f"http://127.0.0.1:{cls.port}"
        for _ in range(100):
            try:
                urllib.request.urlopen(cls.base + "/api/me", timeout=0.2)
                break
            except Exception:
                if cls.proc.poll() is not None:
                    raise RuntimeError("server process exited during startup")
                time.sleep(0.05)
        else:
            raise RuntimeError("server process did not start")

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        cls.proc.wait(timeout=5)
        cls.temp.cleanup()

    def setUp(self):
        self.jar = http.cookiejar.CookieJar()
        self.client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def request(self, path, method="GET", value=None, raw=None):
        headers = {}
        data = raw
        if value is not None:
            data = json.dumps(value).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with self.client.open(req, timeout=15) as response:
                return response.status, response.read(), response.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers

    def register(self, username):
        status, body, _ = self.request("/api/register", "POST", {"username": username, "password": "long test password"})
        self.assertEqual(status, 200, body)

    def upload(self, path, content, token):
        query = urllib.parse.urlencode({"path": path, "total": len(content), "index": 0, "count": 1, "token": token, "modified": 1720000000})
        return self.request("/api/upload?" + query, "POST", raw=content)

    def test_account_isolation_and_download_export(self):
        self.register("alice")
        status, body, _ = self.upload("docs/report.txt", b"first version", "a" * 48)
        self.assertEqual(status, 200, body)
        self.assertTrue(json.loads(body)["done"])
        status, body, _ = self.upload("docs/report.txt", b"second version", "b" * 48)
        self.assertEqual(status, 200, body)
        data = json.loads(body)
        self.assertEqual(data["path"], "docs/report (\u51b2\u7a81\u526f\u672c 2).txt")

        status, body, _ = self.request("/api/files")
        files = json.loads(body)["files"]
        self.assertEqual(len(files), 2)
        status, body, _ = self.request(f"/api/download/{files[0]['id']}")
        self.assertIn(body, (b"first version", b"second version"))

        status, body, headers = self.request("/api/export", "POST", {})
        self.assertEqual(status, 200)
        with zipfile.ZipFile(BytesIO(body)) as archive:
            self.assertEqual(len(archive.namelist()), 2)

        other = ApiTest()
        other.setUp()
        other.register("bob")
        status, body, _ = other.request("/api/files")
        self.assertEqual(json.loads(body)["files"], [])

    def test_rejects_traversal_and_bad_password(self):
        self.register("carol")
        query = urllib.parse.urlencode({"path": "../outside.txt", "total": 1, "index": 0, "count": 1, "token": "x" * 40})
        status, _, _ = self.request("/api/upload?" + query, "POST", raw=b"x")
        self.assertEqual(status, 400)
        self.request("/api/logout", "PUT")
        status, _, _ = self.request("/api/login", "POST", {"username": "carol", "password": "wrong password"})
        self.assertEqual(status, 401)

    def test_rejects_weak_registration(self):
        status, _, _ = self.request("/api/register", "POST", {"username": "ab", "password": "123"})
        self.assertEqual(status, 400)

    def test_folder_delete_removes_nested_files(self):
        self.register("folderuser")
        self.assertEqual(self.upload("photos/one.txt", b"1", "c" * 48)[0], 200)
        self.assertEqual(self.upload("photos/nested/two.txt", b"2", "d" * 48)[0], 200)
        status, body, _ = self.request("/api/folders?path=photos", "DELETE")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["deleted"], 2)
        status, body, _ = self.request("/api/files")
        self.assertEqual(json.loads(body)["files"], [])

    def test_folder_delete_escapes_like_characters_and_keeps_shared_blob(self):
        self.register("folderchars")
        self.assertEqual(self.upload("docs_100%/one.txt", b"shared", "e" * 48)[0], 200)
        self.assertEqual(self.upload("docs_100%_archive/two.txt", b"shared", "f" * 48)[0], 200)

        status, body, _ = self.request("/api/folders?path=docs_100%25", "DELETE")
        self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)["deleted"], 1)

        status, body, _ = self.request("/api/files")
        files = json.loads(body)["files"]
        self.assertEqual([file["path"] for file in files], ["docs_100%_archive/two.txt"])
        status, body, _ = self.request(f"/api/download/{files[0]['id']}")
        self.assertEqual((status, body), (200, b"shared"))


if __name__ == "__main__":
    unittest.main()
