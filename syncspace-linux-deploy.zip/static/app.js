const $ = (s) => document.querySelector(s);
const state = { files: [], folders: [], folder: null, currentFolder: '', registering: false, busy: false, snapshots: {}, snapshotDirs: [] };
const DB_NAME = 'syncspace-local';

async function api(path, options = {}) {
  const response = await fetch(path, { credentials: 'same-origin', ...options });
  if (!response.ok) {
    let message = `请求失败 (${response.status})`;
    try { message = (await response.json()).error || message; } catch {}
    throw new Error(message);
  }
  return response;
}
function json(method, value) { return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(value) }; }
function toast(text) { const el = $('#toast'); el.textContent = text; el.classList.add('show'); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2800); }
function formatSize(size) { if (size < 1000) return `${size} B`; const units = ['KB', 'MB', 'GB', 'TB', 'PB']; let n = size; let i = -1; do { n /= 1000; i++; } while (n >= 1000 && i < units.length - 1); return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${units[i]}`; }
function formatDate(timestamp) { return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(timestamp * 1000)); }
function extClass(name) { const ext = name.split('.').pop().toLowerCase(); if (ext === 'pdf') return ['pdf', 'PDF']; if (['png','jpg','jpeg','gif','webp','svg','heic'].includes(ext)) return ['img', ext.slice(0,3).toUpperCase()]; if (['doc','docx','txt','md','rtf'].includes(ext)) return ['doc', 'DOC']; if (['zip','7z','rar','gz','tar'].includes(ext)) return ['zip', 'ZIP']; return ['', ext.slice(0,3).toUpperCase() || 'FILE']; }

async function refresh() {
  const data = await (await api('/api/files')).json();
  state.files = data.files;
  state.folders = data.folders || [];
  render();
}
function render() {
  const allBytes = state.files.reduce((sum, file) => sum + file.size, 0);
  const folders = new Set(state.folders);
  state.files.forEach(file => { const parts = file.path.split('/'); for (let i = 1; i < parts.length; i++) folders.add(parts.slice(0, i).join('/')); });
  const folderNav = $('#folder-nav'); folderNav.replaceChildren();
  [...folders].sort((a,b) => a.localeCompare(b)).forEach(folder => {
    const depth = folder.split('/').length;
    const button = document.createElement('button'); button.className = `folder-link ${state.currentFolder === folder ? 'active' : ''}`; button.style.paddingLeft = `${15 + depth * 11}px`; button.textContent = `▱  ${folder.split('/').at(-1)}`; button.title = folder;
    button.onclick = () => { state.currentFolder = folder; render(); }; folderNav.append(button);
  });
  $('#nav-count').textContent = state.files.length;
  $('#file-count-label').textContent = `${state.files.length} 个文件`;
  $('#visible-count').textContent = `${visibleFiles().length + visibleFolders().length} 项`;
  $('#storage-value').textContent = formatSize(allBytes);
  $('#storage-fill').style.width = `${allBytes ? 100 : 0}%`;
  const label = state.currentFolder || '全部文件';
  $('#current-folder').textContent = label;
  $('#mobile-title').textContent = label;
  $('#nav-all').classList.toggle('active', !state.currentFolder);
  const body = $('#file-list'); body.replaceChildren();
  visibleFolders().forEach(folder => {
    const tr = document.createElement('tr'); tr.className = 'folder-row'; tr.dataset.folder = folder;
    const children = state.files.filter(file => file.path.startsWith(folder + '/')).length;
    tr.innerHTML = `<td><div class="file-name"><span class="file-type">DIR</span><button class="file-name-text folder-open" title="打开文件夹">${escapeHTML(folder.split('/').at(-1))}</button></div></td><td>${children} 项</td><td>—</td><td><span class="status"><i></i>文件夹</span></td><td><div class="row-actions"><button class="row-action delete-folder" title="删除文件夹" aria-label="删除文件夹">×</button></div></td>`;
    tr.querySelector('.folder-open').onclick = () => { state.currentFolder = folder; render(); };
    tr.querySelector('.delete-folder').onclick = async () => { if (!confirm(`删除文件夹“${folder}”及其中的全部文件？`)) return; try { await api(`/api/folders?path=${encodeURIComponent(folder)}`, { method: 'DELETE' }); if (state.currentFolder === folder || state.currentFolder.startsWith(folder + '/')) state.currentFolder = ''; await refresh(); toast('文件夹及其内容已删除'); } catch (error) { toast(error.message); } };
    tr.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('application/x-syncspace-file')) { e.preventDefault(); tr.style.background = '#f0f7ef'; } });
    tr.addEventListener('dragleave', () => { tr.style.background = ''; });
    tr.addEventListener('drop', async e => {
      const id = e.dataTransfer.getData('application/x-syncspace-file'); if (!id) return; e.preventDefault(); e.stopPropagation(); tr.style.background = '';
      const file = state.files.find(item => item.id === Number(id)); if (!file) return;
      const destination = `${folder}/${file.path.split('/').at(-1)}`;
      try { await api('/api/move', json('POST', { id: file.id, path: destination })); await refresh(); toast('文件已移入文件夹'); } catch (error) { toast(error.message); }
    });
    body.append(tr);
  });
  visibleFiles().forEach(file => {
    const tr = document.createElement('tr'); tr.draggable = true; tr.dataset.id = file.id; tr.dataset.path = file.path;
    const [type, ext] = extClass(file.path);
    tr.innerHTML = `<td><div class="file-name"><span class="file-type ${type}">${escapeHTML(ext)}</span><span class="file-name-text" title="${escapeHTML(file.path)}">${escapeHTML(file.path.split('/').at(-1))}</span></div></td><td>${formatSize(file.size)}</td><td>${formatDate(file.modified)}</td><td><span class="status"><i></i>已同步</span></td><td><div class="row-actions"><button class="row-action download" title="下载文件" aria-label="下载文件">↓</button><button class="row-action delete" title="从云端移除" aria-label="从云端移除">×</button></div></td>`;
    tr.querySelector('.download').onclick = () => { location.href = `/api/download/${file.id}`; };
    tr.querySelector('.delete').onclick = async () => { if (!confirm(`从云端移除“${file.path}”？`)) return; try { await api(`/api/files/${file.id}`, { method: 'DELETE' }); await refresh(); toast('已从云端移除'); } catch (e) { toast(e.message); } };
    tr.addEventListener('dragstart', e => { e.dataTransfer.setData('application/x-syncspace-file', String(file.id)); e.dataTransfer.effectAllowed = 'move'; });
    body.append(tr);
  });
  const isEmpty = visibleFiles().length + visibleFolders().length === 0;
  $('#empty-state').classList.toggle('hidden', !isEmpty);
  $('.table-wrap').classList.toggle('hidden', isEmpty);
}
function visibleFiles() {
  const search = $('#search').value.trim().toLowerCase();
  return state.files.filter(f => {
    const parent = f.path.includes('/') ? f.path.slice(0, f.path.lastIndexOf('/')) : '';
    return parent === state.currentFolder && (!search || f.path.toLowerCase().includes(search));
  });
}
function visibleFolders() {
  const search = $('#search').value.trim().toLowerCase();
  const all = new Set(state.folders);
  state.files.forEach(file => { const parts = file.path.split('/'); for (let i = 1; i < parts.length; i++) all.add(parts.slice(0, i).join('/')); });
  return [...all].filter(path => {
    const parent = path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '';
    return parent === state.currentFolder && (!search || path.toLowerCase().includes(search));
  }).sort((a,b) => a.localeCompare(b));
}
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

async function sendFile(file, relativePath) {
  const chunkSize = 8 * 1024 * 1024;
  const count = Math.max(1, Math.ceil(file.size / chunkSize));
  const token = crypto.randomUUID() + crypto.randomUUID();
  for (let index = 0; index < count; index++) {
    const chunk = file.slice(index * chunkSize, Math.min(file.size, (index + 1) * chunkSize));
    const query = new URLSearchParams({ path: relativePath, total: String(file.size), index: String(index), count: String(count), token, modified: String(file.lastModified ? file.lastModified / 1000 : Date.now() / 1000) });
    const response = await fetch(`/api/upload?${query}`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: chunk });
    if (!response.ok) { let message = `上传失败 (${response.status})`; try { message = (await response.json()).error || message; } catch {} throw new Error(message); }
    const result = await response.json();
    updateProgress(relativePath.split('/').at(-1), index + 1, count);
    if (result.done) return result;
  }
}
function updateProgress(label, done, total) { $('#progress-panel').classList.remove('hidden'); $('#progress-label').textContent = label; $('#progress-count').textContent = `${done} / ${total} 块`; $('#progress-fill').style.width = `${Math.round(done / total * 100)}%`; }
async function uploadEntries(entries, label = '正在上传', fromFolderSync = false) {
  if (state.busy) { toast('当前有同步任务正在进行'); return; }
  state.busy = true; $('#progress-panel').classList.remove('hidden'); $('#progress-label').textContent = label;
  let done = 0; const total = entries.length; $('#progress-count').textContent = `0 / ${total} 个文件`;
  try {
    for (const entry of entries) {
      await sendFile(entry.file, entry.path);
      if (fromFolderSync && state.folder) state.snapshots[entry.path] = { size: entry.file.size, modified: entry.file.lastModified || 0 };
      done++;
      $('#progress-count').textContent = `${done} / ${total} 个文件`;
      $('#progress-fill').style.width = `${Math.round(done / total * 100)}%`;
    }
    if (fromFolderSync && state.folder) await saveSnapshot(state.folder.name, state.snapshots);
    await refresh(); markSync(); toast(total ? `已同步 ${done} 个文件` : '文件已是最新状态');
  } catch (error) { toast(error.message); }
  finally { state.busy = false; setTimeout(() => $('#progress-panel').classList.add('hidden'), 1100); }
}
function markSync() { const now = new Date(); const text = `刚刚 · ${now.toLocaleTimeString('zh-CN', {hour:'2-digit', minute:'2-digit'})}`; $('#last-sync').textContent = text; $('#sync-detail').textContent = `最近同步 ${text}`; }
function fileEntries(files, prefix = '') { return [...files].map(file => ({ file, path: `${prefix}${file.webkitRelativePath || file.name}` })); }

function openDB() { return new Promise((resolve, reject) => { const request = indexedDB.open(DB_NAME, 2); request.onupgradeneeded = () => { const db = request.result; if (!db.objectStoreNames.contains('handles')) db.createObjectStore('handles'); if (!db.objectStoreNames.contains('snapshots')) db.createObjectStore('snapshots'); }; request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); }
async function saveHandle(handle) { const db = await openDB(); await new Promise((resolve, reject) => { const tx = db.transaction('handles', 'readwrite'); tx.objectStore('handles').put(handle, 'sync-folder'); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
async function getHandle() { const db = await openDB(); return new Promise((resolve, reject) => { const tx = db.transaction('handles'); const request = tx.objectStore('handles').get('sync-folder'); request.onsuccess = () => resolve(request.result || null); request.onerror = () => reject(request.error); }); }
async function loadSnapshot(name) { const db = await openDB(); return new Promise((resolve, reject) => { const request = db.transaction('snapshots').objectStore('snapshots').get(name); request.onsuccess = () => resolve(request.result || {}); request.onerror = () => reject(request.error); }); }
async function saveSnapshot(name, value) { const db = await openDB(); await new Promise((resolve, reject) => { const tx = db.transaction('snapshots', 'readwrite'); tx.objectStore('snapshots').put(value, name); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
async function loadSnapshotDirs(name) { const db = await openDB(); return new Promise((resolve, reject) => { const request = db.transaction('snapshots').objectStore('snapshots').get(`dirs:${name}`); request.onsuccess = () => resolve(request.result || []); request.onerror = () => reject(request.error); }); }
async function saveSnapshotDirs(name, value) { const db = await openDB(); await new Promise((resolve, reject) => { const tx = db.transaction('snapshots', 'readwrite'); tx.objectStore('snapshots').put(value, `dirs:${name}`); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
async function verifyPermission(handle, prompt = false) { const opts = { mode: 'readwrite' }; if (await handle.queryPermission(opts) === 'granted') return true; return prompt && await handle.requestPermission(opts) === 'granted'; }
async function connectFolder() {
  if (!window.showDirectoryPicker) { $('#folder-input').click(); toast('当前浏览器不支持直接连接文件夹，已打开文件夹选择'); return; }
  try { const handle = await window.showDirectoryPicker({ mode: 'readwrite' }); if (!(await verifyPermission(handle, true))) { toast('未获得文件夹访问权限'); return; } state.folder = handle; state.snapshots = await loadSnapshot(handle.name); state.snapshotDirs = await loadSnapshotDirs(handle.name); await saveHandle(handle); $('#sync-detail').textContent = `已连接本地文件夹：${handle.name}`; toast(`已连接 ${handle.name}`); await syncFolder(); }
  catch (e) { if (e.name !== 'AbortError') toast(e.message); }
}
async function collectLocal(handle, prefix = '') {
  const files = []; const directories = [];
  for await (const [name, child] of handle.entries()) {
    if (name.startsWith('.')) continue;
    const path = `${prefix}${name}`;
    if (child.kind === 'directory') { directories.push(path); const nested = await collectLocal(child, `${path}/`); files.push(...nested.files); directories.push(...nested.directories); }
    else { const file = await child.getFile(); files.push({ file, path, handle: child }); }
  }
  return { files, directories };
}
async function syncFolder() {
  if (!state.folder) return;
  if (state.busy) { toast('同步任务正在进行'); return; }
  if (!(await verifyPermission(state.folder, false))) { toast('请重新连接本地文件夹以授予访问权限'); return; }
  state.busy = true; $('#progress-label').textContent = '正在比对设备文件'; $('#progress-count').textContent = '读取文件列表…'; $('#progress-panel').classList.remove('hidden');
  try {
    const { files: local, directories: localDirectories } = await collectLocal(state.folder);
    const cloud = new Map(state.files.map(f => [f.path, f]));
    const localMap = new Map(local.map(entry => [entry.path, entry]));
    const toUpload = [];
    for (const entry of local) {
      const server = cloud.get(entry.path);
      const snapshot = state.snapshots[entry.path];
      const acknowledged = snapshot && snapshot.size === entry.file.size && snapshot.modified === entry.file.lastModified;
      if (snapshot && !server && acknowledged) {
        const parts = entry.path.split('/'); const name = parts.pop(); let dir = state.folder;
        try { for (const part of parts) dir = await dir.getDirectoryHandle(part); await dir.removeEntry(name); localMap.delete(entry.path); delete state.snapshots[entry.path]; }
        catch (e) { console.warn('Cloud deletion propagation skipped', entry.path, e); }
        continue;
      }
      if (!acknowledged && (!server || server.size !== entry.file.size || Math.abs(server.modified - entry.file.lastModified / 1000) > 2)) toUpload.push(entry);
    }
    for (const remote of state.files) {
      if (localMap.has(remote.path)) continue;
      if (state.snapshots[remote.path]) {
        // A remembered file missing locally means the user deleted it on this device.
        try { await api(`/api/files/${remote.id}`, { method: 'DELETE' }); } catch (e) { console.warn('Delete propagation skipped', remote.path, e); }
        delete state.snapshots[remote.path];
        continue;
      }
      const parts = remote.path.split('/'); const name = parts.pop(); let dir = state.folder;
      try { for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: true }); const fh = await dir.getFileHandle(name, { create: true }); const writable = await fh.createWritable(); const response = await api(`/api/download/${remote.id}`); await response.body.pipeTo(writable); const saved = await fh.getFile(); state.snapshots[remote.path] = { size: saved.size, modified: saved.lastModified }; }
      catch (e) { console.warn('Download skipped', remote.path, e); }
    }
    for (const snapshotPath of Object.keys(state.snapshots)) {
      if (localMap.has(snapshotPath) || cloud.has(snapshotPath)) continue;
      // A remembered file missing in the cloud was deleted on another device.
      const parts = snapshotPath.split('/'); const name = parts.pop(); let dir = state.folder;
      try { for (const part of parts) dir = await dir.getDirectoryHandle(part); await dir.removeEntry(name); } catch (e) { console.warn('Local delete propagation skipped', snapshotPath, e); }
      delete state.snapshots[snapshotPath];
    }
    const localDirs = new Set(localDirectories);
    const cloudDirs = new Set(state.folders);
    state.files.forEach(file => { const parts = file.path.split('/'); for (let i = 1; i < parts.length; i++) cloudDirs.add(parts.slice(0, i).join('/')); });
    const oldDirs = new Set(state.snapshotDirs);
    for (const folder of oldDirs) {
      if (!localDirs.has(folder) && cloudDirs.has(folder)) {
        try { await api(`/api/folders?path=${encodeURIComponent(folder)}`, { method: 'DELETE' }); } catch (e) { console.warn('Folder delete propagation skipped', folder, e); }
      } else if (localDirs.has(folder) && !cloudDirs.has(folder)) {
        const parts = folder.split('/'); const name = parts.pop(); let dir = state.folder;
        try { for (const part of parts) dir = await dir.getDirectoryHandle(part); await dir.removeEntry(name, { recursive: true }); } catch (e) { console.warn('Local folder removal skipped', folder, e); }
      }
    }
    for (const folder of cloudDirs) {
      if (localDirs.has(folder)) continue;
      const previouslyKnown = oldDirs.has(folder);
      if (previouslyKnown) continue;
      try { let dir = state.folder; for (const part of folder.split('/')) dir = await dir.getDirectoryHandle(part, { create: true }); localDirs.add(folder); } catch (e) { console.warn('Folder create skipped', folder, e); }
    }
    for (const folder of localDirs) if (!cloudDirs.has(folder) && !oldDirs.has(folder)) {
      try { await api('/api/mkdir', json('POST', { path: folder })); cloudDirs.add(folder); } catch (e) { console.warn('Cloud folder create skipped', folder, e); }
    }
    state.snapshotDirs = [...localDirs].filter(folder => cloudDirs.has(folder));
    await saveSnapshot(state.folder.name, state.snapshots);
    await saveSnapshotDirs(state.folder.name, state.snapshotDirs);
    $('#progress-panel').classList.add('hidden');
    if (toUpload.length) { state.busy = false; await uploadEntries(toUpload, '正在同步本地更改', true); return; }
    await refresh(); markSync(); toast('设备与云端已同步');
  } catch (e) { toast(e.message); }
  finally { state.busy = false; setTimeout(() => $('#progress-panel').classList.add('hidden'), 1100); }
}

async function walkDrop(items, prefix = '') {
  const output = [];
  for (const item of items) {
    if (item.kind !== 'file') continue;
    const entry = item.webkitGetAsEntry?.();
    if (entry?.isDirectory) { output.push(...await walkWebkitDirectory(entry, prefix)); continue; }
    const file = item.getAsFile();
    if (file) output.push({ file, path: `${prefix}${file.name}` });
  }
  return output;
}
async function walkWebkitDirectory(entry, prefix) {
  const next = `${prefix}${entry.name}/`; const reader = entry.createReader(); const all = [];
  while (true) { const chunk = await new Promise((resolve, reject) => reader.readEntries(resolve, reject)); if (!chunk.length) break; all.push(...chunk); }
  const output = [];
  for (const child of all) {
    if (child.isFile) { const file = await new Promise(resolve => child.file(resolve)); output.push({ file, path: `${next}${file.name}` }); }
    else output.push(...await walkWebkitDirectory(child, next));
  }
  return output;
}

function authMode(registering) {
  state.registering = registering;
  $('#auth-eyebrow').textContent = registering ? 'CREATE YOUR SPACE' : 'WELCOME BACK';
  $('#auth-title').textContent = registering ? '创建你的空间' : '登录你的空间';
  $('#auth-desc').textContent = registering ? '设置账号后，即可在各设备间访问文件。' : '文件正在你的私有空间中等待。';
  $('#auth-submit').innerHTML = registering ? '创建账号 <span>→</span>' : '登录 <span>→</span>';
  $('#auth-toggle').textContent = registering ? '返回登录' : '创建账号';
  $('#auth-switch-text').textContent = registering ? '已经有账号？' : '还没有账号？';
  $('#auth-pass').autocomplete = registering ? 'new-password' : 'current-password';
  $('#auth-pass').minLength = registering ? 10 : 1;
  $('#auth-error').textContent = '';
}
async function showApp(user) {
  $('#auth-screen').classList.add('hidden'); $('#app').classList.remove('hidden');
  $('#username').textContent = user.username; $('#avatar').textContent = user.username.slice(0,1).toUpperCase();
  try { state.folder = await getHandle(); if (state.folder && await verifyPermission(state.folder)) { state.snapshots = await loadSnapshot(state.folder.name); state.snapshotDirs = await loadSnapshotDirs(state.folder.name); $('#sync-detail').textContent = `已连接本地文件夹：${state.folder.name}`; } else state.folder = null; } catch { state.folder = null; }
  await refresh();
  if (state.folder) await syncFolder();
}

$('#auth-toggle').onclick = () => authMode(!state.registering);
$('#auth-form').onsubmit = async event => {
  event.preventDefault(); $('#auth-error').textContent = '';
  const endpoint = state.registering ? '/api/register' : '/api/login';
  try { await api(endpoint, json('POST', { username: $('#auth-user').value, password: $('#auth-pass').value })); const me = await (await api('/api/me')).json(); await showApp(me); }
  catch (e) { $('#auth-error').textContent = e.message; }
};
$('#logout').onclick = async () => { try { await api('/api/logout', { method: 'PUT' }); location.reload(); } catch (e) { toast(e.message); } };
$('#upload-trigger').onclick = () => $('#file-input').click(); $('#mobile-upload').onclick = () => $('#file-input').click(); $('#empty-upload').onclick = () => $('#file-input').click();
$('#upload-folder').onclick = () => $('#folder-input').click(); $('#file-input').onchange = e => uploadEntries(fileEntries(e.target.files, state.currentFolder ? `${state.currentFolder}/` : '')); $('#folder-input').onchange = e => uploadEntries(fileEntries(e.target.files, state.currentFolder ? `${state.currentFolder}/` : ''));
$('#choose-folder').onclick = connectFolder; $('#sync-now').onclick = () => state.folder ? syncFolder() : toast('请先连接本地文件夹');
$('#export-all').onclick = () => { location.href = '/api/export'; };
$('#search').oninput = () => render();
$('#nav-all').onclick = () => { state.currentFolder = ''; render(); };
$('#new-folder').onclick = async () => { const name = prompt('新文件夹名称'); if (!name?.trim()) return; const path = `${state.currentFolder ? state.currentFolder + '/' : ''}${name.trim()}`; try { await api('/api/mkdir', json('POST', { path })); await refresh(); toast('文件夹已创建'); } catch (error) { toast(error.message); } };
$('#drop-zone').addEventListener('dragover', e => { e.preventDefault(); e.currentTarget.classList.add('dragging'); });
$('#drop-zone').addEventListener('dragleave', e => { if (!e.currentTarget.contains(e.relatedTarget)) e.currentTarget.classList.remove('dragging'); });
$('#drop-zone').addEventListener('drop', async e => {
  e.preventDefault(); e.currentTarget.classList.remove('dragging');
  const moving = e.dataTransfer.getData('application/x-syncspace-file');
  if (moving) { const folders = [...new Set(state.files.map(f => f.path.split('/').slice(0,-1).join('/')).filter(Boolean))]; const target = prompt(`移动到哪个文件夹？\n${folders.join('\n')}`, state.currentFolder); if (target === null) return; const file = state.files.find(f => f.id === Number(moving)); if (!file) return; const destination = `${target ? target.replace(/\/$/, '') + '/' : ''}${file.path.split('/').at(-1)}`; try { await api('/api/move', json('POST', { id: file.id, path: destination })); await refresh(); toast('文件已移动并合并到目标文件夹'); } catch (err) { toast(err.message); } return; }
  const prefix = state.currentFolder ? `${state.currentFolder}/` : '';
  const items = [...(e.dataTransfer.items || [])]; const entries = items.length ? await walkDrop(items, prefix) : fileEntries(e.dataTransfer.files, prefix); if (!entries.length) { toast('没有找到可上传的文件'); return; } await uploadEntries(entries, '正在合并拖入文件');
});

async function boot() {
  if ('serviceWorker' in navigator && location.protocol !== 'http:' || ('serviceWorker' in navigator && location.hostname === 'localhost')) navigator.serviceWorker.register('/service-worker.js').catch(() => {});
  try { const user = await (await api('/api/me')).json(); if (user.username) await showApp(user); } catch {}
  setInterval(async () => { if (!$('#app').classList.contains('hidden') && state.folder && !document.hidden) await syncFolder(); }, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && state.folder && !$('#app').classList.contains('hidden')) syncFolder(); });
}
boot();
