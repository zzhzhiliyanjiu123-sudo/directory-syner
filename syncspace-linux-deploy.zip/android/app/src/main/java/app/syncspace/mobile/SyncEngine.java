package app.syncspace.mobile;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.webkit.CookieManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** SAF directory scanner. The selected tree is the only local location it can read. */
final class SyncEngine {
    interface Listener { void status(String value); }
    private static final int CHUNK = 8 * 1024 * 1024;
    private final Context context;
    private final ContentResolver resolver;
    private final SharedPreferences prefs;
    private final Listener listener;
    private String base;
    private Uri tree;
    private boolean running;
    private final Map<String, JSONObject> snapshot = new HashMap<>();

    SyncEngine(Context c, Listener l) { context = c; resolver = c.getContentResolver(); prefs = c.getSharedPreferences("syncspace-mobile", Context.MODE_PRIVATE); listener = l; base = prefs.getString("server", ""); String saved = prefs.getString("tree", ""); if (!saved.isEmpty()) tree = Uri.parse(saved); loadSnapshot(); }
    void setServer(String value) { base = value.replaceAll("/+$", ""); prefs.edit().putString("server", base).apply(); }
    Uri getTree() { return tree; }
    void setTree(Uri value) { tree = value; context.getContentResolver().takePersistableUriPermission(value, 3); prefs.edit().putString("tree", value.toString()).apply(); }
    void syncAsync() { if (running || tree == null || base.isEmpty()) return; running = true; new Thread(() -> { try { sync(); } catch (Exception e) { listener.status("同步失败：" + e.getMessage()); } finally { running = false; } }, "syncspace-scanner").start(); }

    private void sync() throws Exception {
        listener.status("正在扫描已选择的 Android 文件夹…");
        Map<String, Local> local = new HashMap<>(); scan(tree, "", local);
        JSONObject listing = requestJson("GET", "/api/files", null); JSONArray files = listing.optJSONArray("files");
        Map<String, JSONObject> cloud = new HashMap<>(); if (files != null) for (int i=0;i<files.length();i++) { JSONObject f=files.getJSONObject(i); cloud.put(f.getString("path"), f); }
        for (Local item : local.values()) {
            JSONObject old = snapshot.get(item.path); JSONObject remote = cloud.get(item.path);
            boolean same = old != null && old.optLong("size", -1) == item.size && old.optLong("modified", -1) == item.modified;
            if (!same && (remote == null || remote.optLong("size", -1) != item.size || Math.abs(remote.optDouble("modified", 0) - item.modified / 1000d) > 2)) { listener.status("上传：" + item.path); upload(item); }
        }
        for (Map.Entry<String, Local> entry : local.entrySet()) {
            JSONObject old = snapshot.get(entry.getKey()); if (old != null && !cloud.containsKey(entry.getKey()) && old.optLong("size", -1) == entry.getValue().size && old.optLong("modified", -1) == entry.getValue().modified) { removeLocal(entry.getKey()); }
        }
        for (Map.Entry<String, JSONObject> entry : cloud.entrySet()) {
            Local item = local.get(entry.getKey()); JSONObject old = snapshot.get(entry.getKey());
            if (item == null && old != null) { deleteCloud(entry.getValue().optInt("id")); }
            else if (item == null && old == null) download(entry.getValue());
        }
        for (String path : new ArrayList<>(snapshot.keySet())) if (!local.containsKey(path) && !cloud.containsKey(path)) snapshot.remove(path);
        for (Local item : local.values()) { JSONObject mark = new JSONObject(); mark.put("size", item.size); mark.put("modified", item.modified); snapshot.put(item.path, mark); }
        saveSnapshot(); listener.status("同步完成：" + local.size() + " 个本地文件");
    }

    private void scan(Uri parent, String prefix, Map<String, Local> out) {
        String id = DocumentsContract.getDocumentId(parent); Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, id);
        try (Cursor c=resolver.query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null,null,null)) {
            if (c == null) return; while(c.moveToNext()) { String childId=c.getString(0), name=c.getString(1), mime=c.getString(2); Uri child=DocumentsContract.buildDocumentUriUsingTree(parent, childId); String path=prefix + name; if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) scan(child, path + "/", out); else out.put(path, new Local(path, child, c.isNull(3)?0:c.getLong(3), c.isNull(4)?0:c.getLong(4))); }
        } catch (Exception ignored) { }
    }
    private void upload(Local item) throws Exception { long total=item.size; int count=Math.max(1,(int)((total+CHUNK-1)/CHUNK)); String token=UUID.randomUUID().toString()+UUID.randomUUID(); try(InputStream in=resolver.openInputStream(item.uri)) { byte[] buf=new byte[CHUNK]; for(int i=0;i<count;i++){ int expected=(int)Math.min(CHUNK,total-(long)i*CHUNK), got=readFully(in,buf,expected); String q="path="+enc(item.path)+"&total="+total+"&index="+i+"&count="+count+"&token="+enc(token)+"&modified="+(item.modified/1000d); requestBytes("POST","/api/upload?"+q,buf,got); } } }
    private int readFully(InputStream in, byte[] b, int n) throws Exception { int p=0,r; while(p<n&&(r=in.read(b,p,n-p))>0)p+=r; return p; }
    private void download(JSONObject f) throws Exception { String path=f.getString("path"); Uri parent=ensureParent(path); String name=path.substring(path.lastIndexOf('/')+1); ContentValues v=new ContentValues(); v.put(DocumentsContract.Document.COLUMN_DISPLAY_NAME,name); v.put(DocumentsContract.Document.COLUMN_MIME_TYPE,"application/octet-stream"); Uri dst=DocumentsContract.createDocument(resolver,parent,"application/octet-stream",name); HttpURLConnection c=connection("GET","/api/download/"+f.getInt("id")); try(InputStream in=c.getInputStream(); OutputStream out=resolver.openOutputStream(dst)){ byte[] b=new byte[1024*1024]; int n; while((n=in.read(b))>0) out.write(b,0,n); } }
    private void removeLocal(String path) { try { String name=path.substring(path.lastIndexOf('/')+1); Uri parent=ensureParent(path); Uri doc=DocumentsContract.buildChildDocumentsUriUsingTree(parent, DocumentsContract.getDocumentId(parent)); try(Cursor c=resolver.query(doc,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){ if(c!=null)while(c.moveToNext())if(name.equals(c.getString(1)))DocumentsContract.deleteDocument(resolver,DocumentsContract.buildDocumentUriUsingTree(parent,c.getString(0))); } } catch(Exception ignored){} }
    private Uri ensureParent(String path) throws Exception { Uri current=tree; String[] parts=path.split("/"); for(int i=0;i<parts.length-1;i++){ String wanted=parts[i]; String id=DocumentsContract.getDocumentId(current); Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(current,id); Uri found=null; try(Cursor c=resolver.query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){ if(c!=null)while(c.moveToNext())if(wanted.equals(c.getString(1))){found=DocumentsContract.buildDocumentUriUsingTree(current,c.getString(0));break;} } if(found==null){found=DocumentsContract.createDocument(resolver,current,DocumentsContract.Document.MIME_TYPE_DIR,wanted);} current=found; } return current; }
    private void deleteCloud(int id) throws Exception { if(id>0) requestJson("DELETE","/api/files/"+id,null); }
    private HttpURLConnection connection(String method,String path) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(base+path).openConnection(); c.setRequestMethod(method); c.setUseCaches(false); c.setConnectTimeout(15000); c.setReadTimeout(60000); String cookie=CookieManager.getInstance().getCookie(base); if(cookie!=null)c.setRequestProperty("Cookie",cookie); return c; }
    private JSONObject requestJson(String method,String path,byte[] data) throws Exception { HttpURLConnection c=connection(method,path); if(data!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(data);}} if(c.getResponseCode()/100!=2)throw new Exception("服务器返回 "+c.getResponseCode()); byte[] b=read(c.getInputStream()); return new JSONObject(new String(b,"UTF-8")); }
    private void requestBytes(String method,String path,byte[] data,int length) throws Exception { HttpURLConnection c=connection(method,path); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/octet-stream");c.setFixedLengthStreamingMode(length);try(OutputStream o=c.getOutputStream()){o.write(data,0,length);} if(c.getResponseCode()/100!=2)throw new Exception("上传失败 "+c.getResponseCode()); }
    private byte[] read(InputStream in)throws Exception{java.io.ByteArrayOutputStream o=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toByteArray();}
    private String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private void loadSnapshot(){try{JSONArray a=new JSONArray(prefs.getString("snapshot","[]"));for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);snapshot.put(x.getString("path"),x);}}catch(Exception ignored){}}
    private void saveSnapshot(){JSONArray a=new JSONArray();for(Map.Entry<String,JSONObject> e:snapshot.entrySet())try{JSONObject x=new JSONObject(e.getValue().toString());x.put("path",e.getKey());a.put(x);}catch(Exception ignored){}prefs.edit().putString("snapshot",a.toString()).apply();}
    private static final class Local { final String path; final Uri uri; final long size,modified; Local(String p,Uri u,long s,long m){path=p;uri=u;size=s;modified=m;} }
}
