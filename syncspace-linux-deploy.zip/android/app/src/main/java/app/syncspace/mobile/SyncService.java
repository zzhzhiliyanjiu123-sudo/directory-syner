package app.syncspace.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the selected SAF directory scanning while Android allows the foreground service to run. */
public final class SyncService extends Service {
    private static final String CHANNEL = "syncspace-sync";
    private SyncEngine engine;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "栖云文件同步", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        startForeground(7, builder.setContentTitle("栖云正在同步").setContentText("扫描已选择的文件夹").setSmallIcon(android.R.drawable.stat_sys_upload).build());
        engine = new SyncEngine(this, value -> { });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        engine.syncAsync();
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
