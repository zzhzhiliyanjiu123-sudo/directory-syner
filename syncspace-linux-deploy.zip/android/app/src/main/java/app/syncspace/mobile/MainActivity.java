package app.syncspace.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URLDecoder;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 20;
    private static final int PICK_TREE = 21;
    private final String preferences = "syncspace-mobile";
    private WebView web;
    private ValueCallback<Uri[]> pendingFileChoice;
    private String serverUrl;
    private SyncEngine sync;
    private TextView syncStatus;
    private final Handler syncHandler = new Handler();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        serverUrl = getPreferences(MODE_PRIVATE).getString("server", "");
        sync = new SyncEngine(this, value -> runOnUiThread(() -> { if (syncStatus != null) syncStatus.setText(value); }));
        buildScreen();
        if (serverUrl.isEmpty()) editServer(); else openServer();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xfff7f9f7);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(6), dp(10), dp(6));
        TextView title = new TextView(this);
        title.setText("栖云");
        title.setTextSize(18);
        title.setTextColor(0xff214b3a);
        title.setTypeface(null, 1);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button settings = new Button(this);
        settings.setText("服务器");
        settings.setOnClickListener(v -> editServer());
        bar.addView(settings, new LinearLayout.LayoutParams(-2, dp(42)));
        Button folder = new Button(this); folder.setText("同步文件夹"); folder.setOnClickListener(v -> chooseTree()); bar.addView(folder, new LinearLayout.LayoutParams(-2, dp(42)));
        Button now = new Button(this); now.setText("立即同步"); now.setOnClickListener(v -> sync.syncAsync()); bar.addView(now, new LinearLayout.LayoutParams(-2, dp(42)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(54)));
        syncStatus = new TextView(this); syncStatus.setText(sync.getTree() == null ? "未选择 Android 同步文件夹" : "已记住 Android 同步文件夹"); syncStatus.setPadding(dp(14), 0, dp(14), dp(4)); root.addView(syncStatus, new LinearLayout.LayoutParams(-1, dp(30)));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                Uri base = Uri.parse(serverUrl);
                if (uri.getHost() != null && uri.getHost().equalsIgnoreCase(base.getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChoice != null) pendingFileChoice.onReceiveValue(null);
                pendingFileChoice = callback;
                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(intent, PICK_FILE); return true; }
                catch (ActivityNotFoundException e) { pendingFileChoice = null; return false; }
            }
        });
        web.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setTitle(fileName(contentDisposition));
                    request.setDescription("正在导出栖云文件");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName(contentDisposition));
                    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
                    Toast.makeText(MainActivity.this, "已开始下载", Toast.LENGTH_SHORT).show();
                } catch (Exception error) { Toast.makeText(MainActivity.this, "下载失败：" + error.getMessage(), Toast.LENGTH_LONG).show(); }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void editServer() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://你的同步服务器地址");
        input.setInputType(17);
        input.setText(serverUrl);
        new AlertDialog.Builder(this).setTitle("连接栖云服务器")
            .setMessage("输入已部署并启用 HTTPS 的栖云网址")
            .setView(input)
            .setNegativeButton("取消", (dialog, which) -> { if (serverUrl.isEmpty()) finish(); })
            .setPositiveButton("连接", (dialog, which) -> {
                String value = input.getText().toString().trim();
                if (!value.startsWith("https://") && !value.startsWith("http://")) value = "https://" + value;
                Uri uri = Uri.parse(value);
                if (uri.getHost() == null) { Toast.makeText(this, "服务器地址无效", Toast.LENGTH_LONG).show(); editServer(); return; }
                serverUrl = value.replaceAll("/+$", "");
                getPreferences(MODE_PRIVATE).edit().putString("server", serverUrl).apply();
                sync.setServer(serverUrl);
                openServer();
            }).show();
    }

    private void openServer() { web.loadUrl(serverUrl); if (sync.getTree() != null) startSyncService(); }

    private void startSyncService() {
        Intent intent = new Intent(this, SyncService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
    }

    private void chooseTree() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_TREE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && pendingFileChoice != null) {
            Uri[] result = resultCode == RESULT_OK && data != null ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
            pendingFileChoice.onReceiveValue(result);
            pendingFileChoice = null;
        }
        if (requestCode == PICK_TREE && resultCode == RESULT_OK && data != null) { sync.setTree(data.getData()); syncStatus.setText("已选择 Android 同步文件夹"); sync.syncAsync(); startSyncService(); }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private String fileName(String disposition) {
        if (disposition != null && disposition.contains("filename*=")) {
            try { return URLDecoder.decode(disposition.substring(disposition.indexOf("''") + 2).replace("\"", "").trim(), "UTF-8"); }
            catch (Exception ignored) { }
        }
        if (disposition != null && disposition.contains("filename=")) return disposition.substring(disposition.indexOf("filename=") + 9).replace("\"", "").trim();
        return "syncspace-export.zip";
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() { super.onResume(); syncHandler.post(syncLoop); }
    @Override protected void onPause() { super.onPause(); syncHandler.removeCallbacks(syncLoop); }
    private final Runnable syncLoop = new Runnable() { @Override public void run() { sync.syncAsync(); syncHandler.postDelayed(this, 60 * 1000L); } };
}
