$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $out | Out-Null
Remove-Item (Join-Path $out '*') -Recurse -Force -ErrorAction SilentlyContinue
$linux = Join-Path $out 'syncspace-linux-deploy.zip'
$items = @('server.py','README.md','static','tests','android','package.ps1','.gitignore')
Compress-Archive -Path ($items | ForEach-Object { Join-Path $root $_ }) -DestinationPath $linux -CompressionLevel Optimal
$apk = Join-Path $root 'android\app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { throw "未找到 APK：请先使用 Android Studio 或 Gradle 构建 $apk" }
$android = Join-Path $out 'syncspace-android.zip'
Compress-Archive -Path $apk,(Join-Path $root 'README.md') -DestinationPath $android -CompressionLevel Optimal
Write-Host "已生成：$linux"
Write-Host "已生成：$android"
