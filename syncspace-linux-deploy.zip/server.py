#!/usr/bin/env python3
"""Syncspace: a small, self-hosted personal file sync server."""
import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import sqlite3
import time
import urllib.parse
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get("SYNC_DATA", ROOT / "data")).resolve()
STORE = DATA / "files"
DB = DATA / "syncspace.sqlite3"
PORT = int(os.environ.get("PORT", "8765"))
CHUNK_SIZE = 8 * 1024 * 1024
SESSION_TTL = 30 * 86400

DATA.mkdir(parents=True, exist_ok=True)
STORE.mkdir(parents=True, exist_ok=True)


def connect():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


with connect() as db:
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, created REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
          token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          expires REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS files (
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          path TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL,
          modified REAL NOT NULL, uploaded REAL NOT NULL, UNIQUE(user_id, path)
        );
        CREATE TABLE IF NOT EXISTS folders (
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          path TEXT NOT NULL, created REAL NOT NULL, PRIMARY KEY(user_id, path)
        );
        CREATE INDEX IF NOT EXISTS files_user ON files(user_id, path);
    """)


def safe_path(value):
    value = str(value or "").replace("\\", "/").strip("/")
    path = PurePosixPath(value)
    if not value or path.is_absolute() or any(p in ("", ".", "..") for p in path.parts):
        raise ValueError("Invalid file path")
    if any("\x00" in p for p in path.parts):
        raise ValueError("Invalid file path")
    return path.as_posix()


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return salt.hex() + ":" + digest.hex()


def check_password(password, stored):
    salt_hex, digest_hex = stored.split(":", 1)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 310000)
    return hmac.compare_digest(digest.hex(), digest_hex)


class Handler(BaseHTTPRequestHandler):
    server_version = "Syncspace/1.0"

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

    def send_json(self, value, status=200):
        payload = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def body_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1024 * 1024:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def user(self):
        cookies = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookies.get("syncspace")
        if not morsel:
            return None
        with connect() as db:
            row = db.execute("SELECT users.id, users.username FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=? AND expires>?", (morsel.value, time.time())).fetchone()
        return row

    def require_user(self):
        user = self.user()
        if not user:
            self.send_json({"error": "请先登录"}, 401)
        return user

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path.startswith("/api/"):
            if parsed.path == "/api/me":
                user = self.user()
                if user:
                    self.send_json({"username": user["username"]})
                else:
                    self.send_json({"username": None})
                return
            user = self.require_user()
            if not user:
                return
            if parsed.path == "/api/files":
                with connect() as db:
                    rows = db.execute("SELECT id,path,size,sha256,modified,uploaded FROM files WHERE user_id=? ORDER BY path COLLATE NOCASE", (user["id"],)).fetchall()
                    folders = db.execute("SELECT path FROM folders WHERE user_id=? ORDER BY path COLLATE NOCASE", (user["id"],)).fetchall()
                self.send_json({"files": [dict(row) for row in rows], "folders": [row["path"] for row in folders], "chunk_size": CHUNK_SIZE})
                return
            if parsed.path.startswith("/api/download/"):
                try:
                    file_id = int(parsed.path.rsplit("/", 1)[1])
                except ValueError:
                    self.send_json({"error": "文件不存在"}, 404)
                    return
                with connect() as db:
                    row = db.execute("SELECT * FROM files WHERE id=? AND user_id=?", (file_id, user["id"])).fetchone()
                if not row:
                    self.send_json({"error": "文件不存在"}, 404)
                    return
                target = STORE / str(user["id"]) / row["sha256"][:2] / row["sha256"]
                if not target.is_file():
                    self.send_json({"error": "文件数据丢失"}, 404)
                    return
                name = Path(row["path"]).name
                self.send_response(200)
                self.send_header("Content-Type", mimetypes.guess_type(name)[0] or "application/octet-stream")
                self.send_header("Content-Length", str(row["size"]))
                self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(name))
                self.end_headers()
                with target.open("rb") as handle:
                    while chunk := handle.read(1024 * 1024):
                        self.wfile.write(chunk)
                return
            self.send_json({"error": "Not found"}, 404)
            return
        name = "index.html" if parsed.path in ("/", "/index.html") else parsed.path.lstrip("/")
        target = (ROOT / "static" / name).resolve()
        if not target.is_relative_to(ROOT / "static") or not target.is_file():
            self.send_error(404)
            return
        content = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(content)))
        if target.name == "service-worker.js":
            self.send_header("Service-Worker-Allowed", "/")
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        data = {}
        if path != "/api/upload":
            try:
                data = self.body_json()
            except (ValueError, json.JSONDecodeError) as exc:
                self.send_json({"error": str(exc)}, 400)
                return
        if path == "/api/register":
            username, password = str(data.get("username", "")).strip(), str(data.get("password", ""))
            if len(username) < 3 or len(username) > 40 or not username.replace("_", "a").replace("-", "a").isalnum():
                self.send_json({"error": "用户名需为 3–40 位字母、数字、下划线或短横线"}, 400)
                return
            if len(password) < 10:
                self.send_json({"error": "密码至少需要 10 位"}, 400)
                return
            try:
                with connect() as db:
                    cur = db.execute("INSERT INTO users(username,password_hash,created) VALUES(?,?,?)", (username, password_hash(password), time.time()))
                    user_id = cur.lastrowid
            except sqlite3.IntegrityError:
                self.send_json({"error": "该用户名已被使用"}, 409)
                return
            self.login_cookie(user_id)
            return
        if path == "/api/login":
            with connect() as db:
                row = db.execute("SELECT id,password_hash FROM users WHERE username=?", (str(data.get("username", "")).strip(),)).fetchone()
            if not row or not check_password(str(data.get("password", "")), row["password_hash"]):
                self.send_json({"error": "用户名或密码不正确"}, 401)
                return
            self.login_cookie(row["id"])
            return
        user = self.require_user()
        if not user:
            return
        if path == "/api/upload":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                get = lambda key, default="": query.get(key, [default])[0]
                relpath = safe_path(get("path"))
                total = int(get("total", "-1"))
                index = int(get("index", "-1"))
                count = int(get("count", "0"))
                if total < 0 or count < 1 or index < 0 or index >= count:
                    raise ValueError("上传参数无效")
                token = str(get("token"))
                if len(token) < 24 or len(token) > 100:
                    raise ValueError("上传会话无效")
            except (ValueError, TypeError) as exc:
                self.send_json({"error": str(exc)}, 400)
                return
            raw_len = int(self.headers.get("Content-Length", "0"))
            if raw_len > CHUNK_SIZE + 1024:
                self.send_json({"error": "分块超出 8 MiB"}, 413)
                return
            chunk = self.rfile.read(raw_len)
            if len(chunk) != raw_len:
                self.send_json({"error": "分块未完整接收"}, 400)
                return
            upload_dir = DATA / "uploads" / str(user["id"])
            upload_dir.mkdir(parents=True, exist_ok=True)
            temp = upload_dir / token
            if index == 0:
                temp.write_bytes(b"")
            if not temp.exists() or temp.stat().st_size != index * CHUNK_SIZE:
                self.send_json({"error": "上传分块顺序错误，请重新上传"}, 409)
                return
            with temp.open("ab") as out:
                out.write(chunk)
            current = temp.stat().st_size
            expected = min(CHUNK_SIZE, max(0, total - index * CHUNK_SIZE))
            if len(chunk) != expected:
                temp.unlink(missing_ok=True)
                self.send_json({"error": "分块大小与声明不符"}, 400)
                return
            if index + 1 < count:
                self.send_json({"received": current, "done": False})
                return
            if current != total:
                temp.unlink(missing_ok=True)
                self.send_json({"error": "文件大小校验失败"}, 400)
                return
            digest = hashlib.sha256()
            with temp.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            sha = digest.hexdigest()
            blob = STORE / str(user["id"]) / sha[:2] / sha
            blob.parent.mkdir(parents=True, exist_ok=True)
            if not blob.exists():
                temp.replace(blob)
            else:
                temp.unlink(missing_ok=True)
            final_path = relpath
            with connect() as db:
                existing = db.execute("SELECT sha256 FROM files WHERE user_id=? AND path=?", (user["id"], final_path)).fetchone()
                if existing and existing["sha256"] != sha:
                    p = PurePosixPath(relpath)
                    stem, suffix = p.stem, p.suffix
                    final_path = f"{p.parent.as_posix()}/" if p.parent.as_posix() != "." else ""
                    prefix = final_path
                    n = 2
                    candidate = f"{prefix}{stem} (冲突副本 {n}){suffix}"
                    while db.execute("SELECT 1 FROM files WHERE user_id=? AND path=?", (user["id"], candidate)).fetchone():
                        n += 1
                        candidate = f"{prefix}{stem} (冲突副本 {n}){suffix}"
                    final_path = candidate
                db.execute("INSERT INTO files(user_id,path,size,sha256,modified,uploaded) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,path) DO UPDATE SET size=excluded.size,sha256=excluded.sha256,modified=excluded.modified,uploaded=excluded.uploaded", (user["id"], final_path, total, sha, float(get("modified", str(time.time()))), time.time()))
                parts = PurePosixPath(final_path).parent.parts
                for end in range(1, len(parts) + 1):
                    db.execute("INSERT OR IGNORE INTO folders(user_id,path,created) VALUES(?,?,?)", (user["id"], "/".join(parts[:end]), time.time()))
            self.send_json({"received": total, "done": True, "path": final_path, "sha256": sha})
            return
        if path == "/api/move":
            try:
                file_id = int(data["id"])
                new_path = safe_path(data["path"])
            except (KeyError, TypeError, ValueError):
                self.send_json({"error": "移动目标无效"}, 400)
                return
            with connect() as db:
                row = db.execute("SELECT * FROM files WHERE id=? AND user_id=?", (file_id, user["id"])).fetchone()
                if not row:
                    self.send_json({"error": "文件不存在"}, 404)
                    return
                if db.execute("SELECT 1 FROM files WHERE user_id=? AND path=?", (user["id"], new_path)).fetchone():
                    self.send_json({"error": "目标位置已有同名文件，请先重命名或移除目标文件"}, 409)
                    return
                db.execute("UPDATE files SET path=?,uploaded=? WHERE id=?", (new_path, time.time(), file_id))
                parts = PurePosixPath(new_path).parent.parts
                for end in range(1, len(parts) + 1):
                    db.execute("INSERT OR IGNORE INTO folders(user_id,path,created) VALUES(?,?,?)", (user["id"], "/".join(parts[:end]), time.time()))
            self.send_json({"ok": True, "path": new_path})
            return
        if path == "/api/mkdir":
            try:
                folder = safe_path(data.get("path"))
            except ValueError as exc:
                self.send_json({"error": str(exc)}, 400)
                return
            with connect() as db:
                parts = folder.split("/")
                for end in range(1, len(parts) + 1):
                    db.execute("INSERT OR IGNORE INTO folders(user_id,path,created) VALUES(?,?,?)", (user["id"], "/".join(parts[:end]), time.time()))
            self.send_json({"ok": True, "path": folder})
            return
        if path == "/api/export":
            # Build the archive on disk so export size is not constrained by RAM.
            import tempfile
            import zipfile
            with connect() as db:
                rows = db.execute("SELECT path,size,sha256 FROM files WHERE user_id=? ORDER BY path", (user["id"],)).fetchall()
            tmp = tempfile.NamedTemporaryFile(prefix="syncspace-export-", suffix=".zip", delete=False, dir=DATA)
            tmp.close()
            try:
                with zipfile.ZipFile(tmp.name, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
                    for row in rows:
                        blob = STORE / str(user["id"]) / row["sha256"][:2] / row["sha256"]
                        if blob.is_file():
                            archive.write(blob, row["path"])
                size = os.path.getsize(tmp.name)
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(size))
                self.send_header("Content-Disposition", "attachment; filename=syncspace-export.zip")
                self.end_headers()
                with open(tmp.name, "rb") as stream:
                    while block := stream.read(1024 * 1024):
                        self.wfile.write(block)
            finally:
                Path(tmp.name).unlink(missing_ok=True)
            return
        self.send_json({"error": "Not found"}, 404)

    def login_cookie(self, user_id):
        token = secrets.token_urlsafe(36)
        with connect() as db:
            db.execute("INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)", (token, user_id, time.time() + SESSION_TTL))
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        secure = "; Secure" if os.environ.get("COOKIE_SECURE", "false").lower() == "true" else ""
        self.send_header("Set-Cookie", f"syncspace={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_TTL}{secure}")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"{}")

    def do_DELETE(self):
        path = urllib.parse.urlparse(self.path).path
        user = self.require_user()
        if not user:
            return
        if path == "/api/folders":
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            try:
                folder = safe_path(query.get("path", [""])[0])
            except ValueError:
                self.send_json({"error": "文件夹不存在"}, 404)
                return
            nested = folder.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "/%"
            with connect() as db:
                rows = db.execute("SELECT id,sha256 FROM files WHERE user_id=? AND (path=? OR path LIKE ? ESCAPE '\\')", (user["id"], folder, nested)).fetchall()
                db.execute("DELETE FROM files WHERE user_id=? AND (path=? OR path LIKE ? ESCAPE '\\')", (user["id"], folder, nested))
                db.execute("DELETE FROM folders WHERE user_id=? AND (path=? OR path LIKE ? ESCAPE '\\')", (user["id"], folder, nested))
                remaining = {row["sha256"] for row in db.execute("SELECT sha256 FROM files WHERE user_id=?", (user["id"],)).fetchall()}
            for row in rows:
                if row["sha256"] not in remaining:
                    (STORE / str(user["id"]) / row["sha256"][:2] / row["sha256"]).unlink(missing_ok=True)
            self.send_json({"ok": True, "deleted": len(rows)})
            return
        try:
            file_id = int(path.rsplit("/", 1)[1])
        except ValueError:
            self.send_json({"error": "文件不存在"}, 404)
            return
        with connect() as db:
            row = db.execute("SELECT id,sha256 FROM files WHERE id=? AND user_id=?", (file_id, user["id"])).fetchone()
            if not row:
                self.send_json({"error": "文件不存在"}, 404)
                return
            db.execute("DELETE FROM files WHERE id=?", (file_id,))
            shared = db.execute("SELECT 1 FROM files WHERE user_id=? AND sha256=? LIMIT 1", (user["id"], row["sha256"])).fetchone()
        if not shared:
            (STORE / str(user["id"]) / row["sha256"][:2] / row["sha256"]).unlink(missing_ok=True)
        self.send_json({"ok": True})

    def do_PUT(self):
        if urllib.parse.urlparse(self.path).path != "/api/logout":
            self.send_json({"error": "Not found"}, 404)
            return
        user = self.user()
        cookies = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookies.get("syncspace")
        if morsel:
            with connect() as db:
                db.execute("DELETE FROM sessions WHERE token=?", (morsel.value,))
        self.send_response(200)
        self.send_header("Set-Cookie", "syncspace=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"{}")


if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    print(f"Syncspace listening at http://{host}:{PORT} (data: {DATA})")
    ThreadingHTTPServer((host, PORT), Handler).serve_forever()
